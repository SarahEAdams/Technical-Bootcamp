# Bonus tasks

* set up a website using [GitHub pages](https://pages.github.com/)
* Browse [public gists](https://help.github.com/articles/about-gists/) ([help](https://help.github.com/articles/about-gists/))
* Browse [GitHub-related tweets](http://tweetedtimes.com/v/3939)
* Watch [Please. Stop Using Git.](https://www.youtube.com/watch?v=o4PFDKIc2fs) and discuss
