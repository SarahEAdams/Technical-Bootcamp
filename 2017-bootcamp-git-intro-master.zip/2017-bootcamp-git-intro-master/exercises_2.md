# Group work in web browser - Part 2

* navigating GitHub to find collaborators - (see next link)
* [adding a collaborator to your repository](https://help.github.com/articles/inviting-collaborators-to-a-personal-repository/)
* editing a shared repository directly
* [writing a commit summary](https://www.google.com/search?q=github+writing+good+commit+summaries&rlz=1C5CHFA_enUS690US690&oq=github+writing+good+commit+summaries&aqs=chrome..69i57j69i64.5480j0j4&sourceid=chrome&ie=UTF-8)
* [forking a repository](https://help.github.com/articles/fork-a-repo/)
* [working on a branch](https://guides.github.com/introduction/flow/)
* [making a pull request](https://help.github.com/articles/creating-a-pull-request/)
* commenting on a pull request
* accepting a pull request
* [leave a comment on a specific line of code](https://github.com/gitlabhq/gitlabhq/issues/3152)
* how to make the most use of the collaboration tools
