# Hands-on work in web browser - Part 1
*as demoed by instructors*

* [create an account](https://github.com/join) - keep in mind that this is a public platform
* [watch this repository](https://help.github.com/articles/watching-repositories/)
* [create a repository](https://help.github.com/articles/create-a-repo/)
* customize a repository - strongly recommended
    - [LICENSE](LICENSE) - [Licensing Initial](https://help.github.com/articles/licensing-a-repository/), [Licensing Supplemental](https://help.github.com/articles/adding-a-license-to-a-repository/)
    - [README.md](README.md) - [About READMEs](https://help.github.com/articles/about-readmes/)
* [create a new issue](https://help.github.com/articles/creating-an-issue/)
* [comment on an issue](https://github.com/UVA-DSI/git-intro/issues/4)
* [create a new file](https://help.github.com/articles/adding-a-file-to-a-repository/)
  * .md
  * .tsv
* [edit an existing file](https://help.github.com/articles/editing-files-in-your-repository/)



